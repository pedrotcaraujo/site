angular.module("app", ["firebase", "ngRoute"]);
